# Daily Quote & Word (free)
Login + admin posting on Supabase free tier, hosted free on GitHub Pages.

1. supabase.com -> New project (free). SQL Editor -> paste `supabase.sql` -> Run.
2. Project Settings -> API: copy **Project URL** and **anon public key** into the top of the script in `index.html`.
   (The anon key is meant to be public; the SQL row-level security protects the data.)
3. Optional: Authentication -> Providers -> Email -> turn off "Confirm email" so sign-up is instant.
4. Open the app, sign up with your email, then run the commented `update profiles set is_admin = true ...` line from `supabase.sql` with your email. Reload: an "Admin" form appears.
5. Push this folder to GitHub -> Settings -> Pages -> deploy from main. Share the link on Instagram/Threads.
Local test in Codespaces: `python3 -m http.server 8080`.
