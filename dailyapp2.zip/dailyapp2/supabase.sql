-- Run once in Supabase: SQL Editor -> New query -> paste -> Run
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  is_admin boolean not null default false
);
create table daily_posts (
  post_date date primary key,
  quote text not null, author text not null,
  word text not null, pos text, meaning text not null, example text
);
alter table profiles enable row level security;
alter table daily_posts enable row level security;

create function is_admin() returns boolean language sql security definer stable as
$$ select coalesce((select is_admin from profiles where id = auth.uid()), false) $$;

create function handle_new_user() returns trigger language plpgsql security definer as
$$ begin insert into profiles(id) values (new.id); return new; end $$;
create trigger on_signup after insert on auth.users for each row execute function handle_new_user();

-- users can only read their own profile; nobody can edit is_admin from the app
create policy "own profile" on profiles for select using (id = auth.uid());
-- any logged-in user can read posts; only admin can write
create policy "read posts" on daily_posts for select to authenticated using (true);
create policy "admin insert" on daily_posts for insert to authenticated with check (is_admin());
create policy "admin update" on daily_posts for update to authenticated using (is_admin());
create policy "admin delete" on daily_posts for delete to authenticated using (is_admin());

-- AFTER you sign up in the app once, make yourself admin (put your email):
-- update profiles set is_admin = true where id = (select id from auth.users where email = 'you@example.com');
